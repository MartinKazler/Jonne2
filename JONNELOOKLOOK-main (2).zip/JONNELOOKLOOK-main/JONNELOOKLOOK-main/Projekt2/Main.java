package Projekt2;

public class Main {
    public static void main(String[] args) {

        new Projekt2.Game();
        
    }
}
