package Projekt2;

public class Update implements Runnable {
    public Update(Gui gui) {
    }

    @Override
    public void run() {
      
    }}
